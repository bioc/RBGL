
// Copyright Aleksey Gurtovoy 2000-2004
// Copyright David Abrahams 2003-2004
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//

// Preprocessed version of "boost/mpl/map/map40.hpp" header
// -- DO NOT modify by hand!

namespace boost { namespace mpl {

template< typename Map>
struct m_at< Map,30 >
{
    typedef typename Map::item30 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 31,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item30;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30
    >
struct map31
    : m_item<
          31
        , typename P30::first
        , typename P30::second
        , map30< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29 >
        >
{
    typedef map31 type;
};

template< typename Map>
struct m_at< Map,31 >
{
    typedef typename Map::item31 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 32,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item31;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31
    >
struct map32
    : m_item<
          32
        , typename P31::first
        , typename P31::second
        , map31< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30 >
        >
{
    typedef map32 type;
};

template< typename Map>
struct m_at< Map,32 >
{
    typedef typename Map::item32 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 33,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item32;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32
    >
struct map33
    : m_item<
          33
        , typename P32::first
        , typename P32::second
        , map32< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31 >
        >
{
    typedef map33 type;
};

template< typename Map>
struct m_at< Map,33 >
{
    typedef typename Map::item33 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 34,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item33;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32, typename P33
    >
struct map34
    : m_item<
          34
        , typename P33::first
        , typename P33::second
        , map33< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32 >
        >
{
    typedef map34 type;
};

template< typename Map>
struct m_at< Map,34 >
{
    typedef typename Map::item34 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 35,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item34;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32, typename P33, typename P34
    >
struct map35
    : m_item<
          35
        , typename P34::first
        , typename P34::second
        , map34< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33 >
        >
{
    typedef map35 type;
};

template< typename Map>
struct m_at< Map,35 >
{
    typedef typename Map::item35 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 36,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item35;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32, typename P33, typename P34
    , typename P35
    >
struct map36
    : m_item<
          36
        , typename P35::first
        , typename P35::second
        , map35< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34 >
        >
{
    typedef map36 type;
};

template< typename Map>
struct m_at< Map,36 >
{
    typedef typename Map::item36 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 37,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item36;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32, typename P33, typename P34
    , typename P35, typename P36
    >
struct map37
    : m_item<
          37
        , typename P36::first
        , typename P36::second
        , map36< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35 >
        >
{
    typedef map37 type;
};

template< typename Map>
struct m_at< Map,37 >
{
    typedef typename Map::item37 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 38,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item37;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32, typename P33, typename P34
    , typename P35, typename P36, typename P37
    >
struct map38
    : m_item<
          38
        , typename P37::first
        , typename P37::second
        , map37< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36 >
        >
{
    typedef map38 type;
};

template< typename Map>
struct m_at< Map,38 >
{
    typedef typename Map::item38 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 39,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item38;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32, typename P33, typename P34
    , typename P35, typename P36, typename P37, typename P38
    >
struct map39
    : m_item<
          39
        , typename P38::first
        , typename P38::second
        , map38< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37 >
        >
{
    typedef map39 type;
};

template< typename Map>
struct m_at< Map,39 >
{
    typedef typename Map::item39 type;
};

template< typename Key, typename T, typename Base >
struct m_item< 40,Key,T,Base >
    : m_item_< Key,T,Base >
{
    typedef pair< Key,T > item39;
};

template<
      typename P0, typename P1, typename P2, typename P3, typename P4
    , typename P5, typename P6, typename P7, typename P8, typename P9
    , typename P10, typename P11, typename P12, typename P13, typename P14
    , typename P15, typename P16, typename P17, typename P18, typename P19
    , typename P20, typename P21, typename P22, typename P23, typename P24
    , typename P25, typename P26, typename P27, typename P28, typename P29
    , typename P30, typename P31, typename P32, typename P33, typename P34
    , typename P35, typename P36, typename P37, typename P38, typename P39
    >
struct map40
    : m_item<
          40
        , typename P39::first
        , typename P39::second
        , map39< P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37,P38 >
        >
{
    typedef map40 type;
};

}}
